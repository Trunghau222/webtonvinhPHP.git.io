<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('block.index');
})->name('trangchu');
// thao tác đăng nhập
Route::get('/login',[
    'as'=>'taikhoan.login',
    'uses'=>'UserController@login',
]);

Route::post('/xulilogin',[
    'as'=>'taikhoan.xulilogin',
    'uses'=>'UserController@xulilogin',
]);

Route::get('/dangxuat',[
    'as'=>'taikhoan.dangxuat',
    'uses'=>'UserController@dangxuat',
]);

// can bo
Route::prefix('taikhoan')->group(function(){
    Route::get('/index',[
        'as'=>'taikhoan.index',
        'uses'=>'UserController@index_taikhoan',
    ]);
    Route::get('/getbyid/{id}',[
        'as'=>'taikhoan.getbyid',
        'uses'=>'UserController@getbyid',
    ]);
    Route::put('/edit',[
        'as'=>'taikhoan.edit',
        'uses'=>'UserController@edit',
    ]);
    Route::get('/delete/{id}',[
        'as'=>'taikhoan.delete',
        'uses'=>'UserController@delete',
    ]);
});
Route::prefix('import')->group(function(){
    Route::get('/index_tonvinh',[
        'as'=>'import.index_tonvinh',
        'uses'=>'ExceltonvinhController@index_tonvinh',
    ]);
    Route::post('/xuly_tonvinh',[
        'as'=>'import.xuly_tonvinh',
        'uses'=>'ExceltonvinhController@xuly_tonvinh',
    ]);

});

// tuowngf
Route::get('/taikhoan/taotaikhoan','UserController@show_register') -> name('page.show_register');
Route::post('register','UserController@store') -> name('page.post');
