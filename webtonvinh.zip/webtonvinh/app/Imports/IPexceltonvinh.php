<?php

namespace App\Imports;

use App\Model\Exceltonvinh;
use Maatwebsite\Excel\Concerns\ToModel;

class IPexceltonvinh implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Exceltonvinh([
            "Hoten"=> $row[0],
            'ngaysinh'=>$row[1],
            'sdt'=>$row[2],
            'diachi'=>$row[3],
            'nhommau'=>$row[4],
            "muctonvinh"=>$row[5],
            "solanhien"=>$row[6],

        ]);
    }
}
