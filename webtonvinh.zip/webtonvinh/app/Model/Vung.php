<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Vung extends Model
{
    protected $fillable=['tenkhuvuc' ];
}
