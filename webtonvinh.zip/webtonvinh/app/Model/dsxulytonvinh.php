<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class dsxulytonvinh extends Model
{
    protected $fillable=['ID_dsexeltonvinh'];
}
