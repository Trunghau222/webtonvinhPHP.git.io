<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class lichsu_exeltonvinh extends Model
{
    protected $fillable=['ID_exeltonvinh'];
}
