<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Exceltonvinh extends Model
{
    protected $fillable=['tenexeltonvinh','ID_dot','ID_vung'];
}
