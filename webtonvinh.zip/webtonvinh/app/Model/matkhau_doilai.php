<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class matkhau_doilai extends Model
{
    protected $fillable=['email','matkhaucu','matkhaumoi'];
}
