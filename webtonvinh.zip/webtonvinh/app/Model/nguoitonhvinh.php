<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class nguoitonhvinh extends Model
{
    protected $fillable=[ 
    'ID_exeltonvinh',
    'hoten',
    'ngaysinh',
    'sodienthoai',
    'diachi',
    'nhommau',
    'nhomRh' ,
    'muctonvinh',
    'solanhien',];

    
    
}
