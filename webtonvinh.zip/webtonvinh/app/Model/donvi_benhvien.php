<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class donvi_benhvien extends Model
{
    protected $fillable=['tendonvi'];
}
