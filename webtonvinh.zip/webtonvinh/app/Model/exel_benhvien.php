<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class exel_benhvien extends Model
{
    protected $fillable=['tenexelbenhvien','ID_donvibenhvien'];
}
