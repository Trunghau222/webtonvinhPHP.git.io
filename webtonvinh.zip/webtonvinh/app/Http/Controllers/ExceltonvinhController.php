<?php

namespace App\Http\Controllers;
use App\Imports\IPexceltonvinh;
use App\Exports\EPexceltonvinh;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;



class ExceltonvinhController extends Controller
{
    public function index_tonvinh()
    {
        return view('page.imprort_tonvinh');
    }
    public function xuly_tonvinh(Request $request)
    {

        $path = $request->file('file')->getRealPath();
        Excel::import(new IPexceltonvinh, $path);
        return back();
    }
    public function xuat_tonvinh(Request $request)
    {

        $path = $request->file('file')->getRealPath();
        Excel::import(new IPexceltonvinh, $path);
        return back();
    }
}
