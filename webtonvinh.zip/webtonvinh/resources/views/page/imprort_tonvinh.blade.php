<link rel="stylesheet" href="{{ asset('css/bootstrap4.min.css') }}" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="{{ asset('css/importtonvimh.css') }}" >

@extends('block.index')
@section('title')
    <title>Import Benh Vien</title>
@endsection
@section('title_page')
    improt tôn vinh
@endsection
@section('content')
<div class="col">
    <form action="{{ route('import.xuly_tonvinh') }}" class="form-import" method="post"  enctype="multipart/form-data">
       @csrf

        <input type="file" name="file" accept=".xlsx" value="nhập file">
        <input type="submit" value="gưi">
    </form>

@endsection
