<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
.dropdown-dark {
    background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.4)) repeat scroll 0 0 #444444;
    border-color: #111111 #0A0A0A #000000;
    box-shadow: 0 1px rgba(255, 255, 255, 0.1) inset, 0 1px 1px rgba(0, 0, 0, 0.2);
}
.dropdown-dark:before {
    border-bottom-color: #AAAAAA;
}
.dropdown-dark:after {
    border-top-color: #AAAAAA;
}
.dropdown-dark .dropdown-select {
    background: none repeat scroll 0 0 #444444;
    color: #AAAAAA;
    text-shadow: 0 1px #000000;
}
.dropdown-dark .dropdown-select:focus {
    color: #CCCCCC;
}
.dropdown-dark .dropdown-select > option {
    background: none repeat scroll 0 0 #444444;
    text-shadow: 0 1px rgba(0, 0, 0, 0.4);
}
    </style>
</head>
<body>
    <div class="dropdown dropdown-dark">
        <select name="two" class="dropdown-select">
          <option value="">Select…</option>
          <option value="1">Option #1</option>
          <option value="2">Option #2</option>
          <option value="3">Option #3</option>
        </select>
  </div>
</body>
</html>
<?php /**PATH E:\tonvinh\webtonvinh\resources\views/taotaikhoan.blade.php ENDPATH**/ ?>