<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap4.min.css')); ?>" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(asset('css/importtonvimh.css')); ?>" >


<?php $__env->startSection('title'); ?>
    <title>Import Benh Vien</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title_page'); ?>
    improt tôn vinh
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col">
    <form action="<?php echo e(route('import.xuly_tonvinh')); ?>" class="form-import" method="post"  enctype="multipart/form-data">
       <?php echo csrf_field(); ?>

        <input type="file" name="file" accept=".xlsx" value="nhập file">
        <input type="submit" value="gưi">
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('block.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\tonvinh\webtonvinh\resources\views/page/imprort_tonvinh.blade.php ENDPATH**/ ?>